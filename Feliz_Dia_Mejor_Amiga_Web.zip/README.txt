# Feliz Día Mejor Amiga - versión web

Abre `index.html` con Chrome para probarlo.

Para compartirlo con todos por WhatsApp:
1. Sube `index.html` a un servicio de hosting estático (por ejemplo GitHub Pages, Netlify o Cloudflare Pages).
2. Obtén el enlace público.
3. Envía ese enlace por WhatsApp.

No necesita Python ni Pygame en el teléfono.
